import React from "react";

export default function Description({ setDescription }) {

  function descriptionChanged(e){
    console.log('from description')
    console.log(e.target.value)
    setDescription(e.target.value)
  }

  return (
    <>
      <div className="description">
        <textarea
          onChange={descriptionChanged}
          rows="5"
          cols="43"
          className="description-box"
          placeholder="Description"
        />
      </div>
    </>
  );
}
